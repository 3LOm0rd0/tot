
declare var Stripe:any;
