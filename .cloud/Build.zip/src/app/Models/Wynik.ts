 export class Wynik{
  nrGonitwyWSezonie: number;
  konIMiejsce:string; 
  konIiMiejsce:string; 
  konIiiMiejsce:string; 
  konIvMiejsce:string; 
  konVMiejsce:string; 
  konViMiejsce:string; 
  konViiMiejsce:string;
 }
 export class WynikAnswer{
     CzyJestWynik:boolean;
 }
