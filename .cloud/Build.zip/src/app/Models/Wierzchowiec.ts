export class Wierzchowiec{
    nrWierzchowca: number;
    nazwaWierzchowca: string;
    rasa: string;
    wiek: number;
    umaszczenie: string;
    plec: string;
    znakiSzczegolne: string;
    wlasciciel: string;
}

export class WierzchowiecInsert{
    nazwaWierzchowca: string;
    rasa: string;
    wiek: number;
    umaszczenie: string;
    plec: string;
    znakiSzczegolne: string;
    wlasciciel: string;
}

export class KursKonia{
    kursPred:number;
}