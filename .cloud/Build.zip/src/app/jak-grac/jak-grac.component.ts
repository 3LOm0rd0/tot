import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jak-grac',
  templateUrl: './jak-grac.component.html',
  styleUrls: ['./jak-grac.component.css']
})
export class JakGracComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
