export const environment = {
//  apiUrl: 'https://10.0.2.2:44373/api/',

apiUrl: 'https://backend20190508075223.azurewebsites.net/api/',
  debugMode: false
};
